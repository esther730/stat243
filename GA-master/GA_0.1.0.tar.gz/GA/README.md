# GA
STAT 243 2017 final project - genetic algorithm
