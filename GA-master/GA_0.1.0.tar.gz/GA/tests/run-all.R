library(testthat)
library(GA)
test_package("GA")
